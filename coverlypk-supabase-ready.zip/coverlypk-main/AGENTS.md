# AGENTS.md

Static site, no build. Read `PLAN.md` for remaining milestones.

- `data/products.js` sets `window.COVERLY_SEED` (settings + products). Used until the admin saves a local catalogue.
- `js/storage.js` exposes `window.Coverly` — all data access (products, cart, orders, account, IndexedDB `images` with `idb:` refs, `imgTag` + `hydrateImages`, `escapeHTML`). Always escape user text.
- `js/ui.js` exposes `window.CoverlyUI`; renders header/footer into `#site-header`/`#site-footer`, product cards, toasts, delegated `[data-add]`.
- `js/orders.js` exposes `window.CoverlyOrders` (WhatsApp text, item table, statuses).
- Script order on each page: data/products.js → js/storage.js → js/ui.js → page script.
- Palette strictly #111111 / #FFFFFF / #F3F3F3 / #888888 / #333333 (plus neutral borders). ES5-style IIFEs, relative paths.
- Never claim cloud storage, real payment, or secure auth. Uploaded images must be watermarked via Canvas; fail loudly if watermarking fails.
