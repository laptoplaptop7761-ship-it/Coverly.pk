/* Coverly.pk — homepage: categories, curated rails, search, filter and sort. */
(function () {
  "use strict";
  var C = window.Coverly;
  var UI = window.CoverlyUI;
  var esc = C.escapeHTML;

  var products = C.getProducts();
  var categories = C.getCategories().filter(function (c) {
    return products.some(function (p) { return p.category === c; });
  });
  var settings = C.getSettings();

  // Stats + free shipping copy
  document.querySelector('[data-stat="products"]').textContent = products.length;
  document.querySelector('[data-stat="categories"]').textContent = categories.length;
  var threshold = Number(settings.freeShippingThreshold) || 0;
  document.querySelectorAll("[data-free-ship]").forEach(function (el) {
    el.textContent = threshold > 0 ? "Free over " + C.formatPrice(threshold) : "Flat " + C.formatPrice(settings.shippingFee);
  });
  document.querySelectorAll("[data-free-ship-amount]").forEach(function (el) { el.textContent = C.formatPrice(threshold); });

  // Categories
  var catGrid = document.getElementById("categoryGrid");
  catGrid.innerHTML = categories.map(function (c) {
    var inCat = products.filter(function (p) { return p.category === c; });
    var cover = inCat.find(function (p) { return p.images[0]; });
    return '<a class="category-tile" href="index.html?category=' + encodeURIComponent(c) + '#shop" data-category-link="' + esc(c) + '">' +
      (cover ? C.imgTag(cover.images[0], "") : "") +
      "<span>" + esc(c) + "<small>" + inCat.length + (inCat.length === 1 ? " item" : " items") + "</small></span></a>";
  }).join("");
  C.hydrateImages(catGrid);

  // Curated rails
  var inStockFirst = function (a, b) { return (b.stock > 0) - (a.stock > 0); };
  var featured = products.filter(function (p) { return p.featured; }).sort(inStockFirst).slice(0, 4);
  if (!featured.length) featured = products.slice(0, 4);
  var newest = products.slice().sort(function (a, b) { return new Date(b.createdAt) - new Date(a.createdAt); }).slice(0, 4);
  var best = products.slice().sort(function (a, b) { return b.sold - a.sold; }).slice(0, 4);
  UI.renderGrid(document.getElementById("featuredGrid"), featured, "Mark products as featured in the admin panel to show them here.");
  UI.renderGrid(document.getElementById("newGrid"), newest);
  UI.renderGrid(document.getElementById("bestGrid"), best);

  // Shop all: search / filter / sort
  var state = {
    q: C.param("q") || "",
    category: C.param("category") || "All",
    sort: C.param("sort") || "featured"
  };
  if (state.category !== "All" && categories.indexOf(state.category) === -1) state.category = "All";

  var searchInput = document.getElementById("shopSearch");
  var sortSelect = document.getElementById("sortSelect");
  var chips = document.getElementById("categoryChips");
  var grid = document.getElementById("shopGrid");
  var count = document.getElementById("resultCount");

  searchInput.value = state.q;
  if ([].some.call(sortSelect.options, function (o) { return o.value === state.sort; })) sortSelect.value = state.sort;
  else state.sort = "featured";

  function renderChips() {
    chips.innerHTML = ["All"].concat(categories).map(function (c) {
      return '<button type="button" class="chip' + (c === state.category ? " active" : "") + '" data-cat="' + esc(c) + '" aria-pressed="' + (c === state.category) + '">' + esc(c) + "</button>";
    }).join("");
  }

  function matches(p, q) {
    if (!q) return true;
    var hay = (p.name + " " + p.category + " " + p.description + " " + p.variants.join(" ")).toLowerCase();
    return q.toLowerCase().split(/\s+/).filter(Boolean).every(function (word) { return hay.indexOf(word) !== -1; });
  }

  var sorters = {
    featured: function (a, b) { return (b.featured - a.featured) || inStockFirst(a, b) || b.sold - a.sold; },
    newest: function (a, b) { return new Date(b.createdAt) - new Date(a.createdAt); },
    popular: function (a, b) { return b.sold - a.sold; },
    "price-asc": function (a, b) { return C.effectivePrice(a) - C.effectivePrice(b); },
    "price-desc": function (a, b) { return C.effectivePrice(b) - C.effectivePrice(a); },
    discount: function (a, b) { return C.discountPercent(b) - C.discountPercent(a); },
    name: function (a, b) { return a.name.localeCompare(b.name); }
  };

  function syncURL() {
    var params = new URLSearchParams();
    if (state.q) params.set("q", state.q);
    if (state.category !== "All") params.set("category", state.category);
    if (state.sort !== "featured") params.set("sort", state.sort);
    var qs = params.toString();
    history.replaceState(null, "", location.pathname + (qs ? "?" + qs : "") + location.hash);
    var headerInput = document.getElementById("headerSearch");
    if (headerInput && document.activeElement !== headerInput) headerInput.value = state.q;
  }

  function renderShop() {
    var list = products
      .filter(function (p) { return state.category === "All" || p.category === state.category; })
      .filter(function (p) { return matches(p, state.q); })
      .sort(sorters[state.sort]);
    var label = state.q ? 'No products match "' + state.q + '". Try a different search or category.' : "No products in this category yet.";
    UI.renderGrid(grid, list, label);
    count.textContent = list.length + (list.length === 1 ? " product" : " products");
    syncURL();
  }

  chips.addEventListener("click", function (e) {
    var btn = e.target.closest("[data-cat]");
    if (!btn) return;
    state.category = btn.getAttribute("data-cat");
    renderChips();
    renderShop();
  });

  var t;
  searchInput.addEventListener("input", function () {
    clearTimeout(t);
    t = setTimeout(function () { state.q = searchInput.value.trim(); renderShop(); }, 150);
  });

  sortSelect.addEventListener("change", function () { state.sort = sortSelect.value; renderShop(); });

  // Header search on the homepage filters live instead of reloading
  var headerForm = document.querySelector(".header-search");
  if (headerForm) {
    headerForm.addEventListener("submit", function (e) {
      e.preventDefault();
      state.q = document.getElementById("headerSearch").value.trim();
      searchInput.value = state.q;
      renderShop();
      document.getElementById("shop").scrollIntoView();
    });
  }

  // Category links on the homepage (nav, tiles, promo) update the filter in place
  document.addEventListener("click", function (e) {
    var a = e.target.closest('a[href^="index.html?category="]');
    if (!a) return;
    var cat = new URL(a.href, location.href).searchParams.get("category");
    if (categories.indexOf(cat) === -1) return;
    e.preventDefault();
    state.category = cat;
    renderChips();
    renderShop();
    document.getElementById("shop").scrollIntoView();
  });

  renderChips();
  renderShop();
  if ((C.param("q") || C.param("category") || C.param("sort")) && !location.hash) {
    document.getElementById("shop").scrollIntoView();
  }
})();
