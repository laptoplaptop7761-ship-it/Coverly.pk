/* Coverly.pk — shopping cart page. */
(function () {
  "use strict";
  var C = window.Coverly;
  var UI = window.CoverlyUI;
  var esc = C.escapeHTML;
  var root = document.getElementById("cartRoot");
  var subtitle = document.getElementById("cartSubtitle");

  function summaryHTML(d, cta) {
    var remaining = d.threshold > 0 ? d.threshold - d.subtotal : 0;
    var pct = d.threshold > 0 ? Math.min(100, Math.round((d.subtotal / d.threshold) * 100)) : 100;
    return (
      '<aside class="panel summary">' +
      "<h2>Order summary</h2>" +
      (d.threshold > 0
        ? '<div class="ship-progress">' + (remaining > 0 ? "Add <strong>" + C.formatPrice(remaining) + "</strong> more for free delivery." : "<strong>You've unlocked free delivery.</strong>") +
          '<div class="ship-bar"><span style="width:' + pct + '%"></span></div></div>'
        : "") +
      '<div class="summary-row"><span>Subtotal</span><span>' + C.formatPrice(d.subtotal) + "</span></div>" +
      '<div class="summary-row"><span>Shipping</span><span>' + (d.shipping === 0 ? "Free" : C.formatPrice(d.shipping)) + "</span></div>" +
      '<div class="summary-row total"><span>Grand total</span><span>' + C.formatPrice(d.total) + "</span></div>" +
      cta +
      "</aside>"
    );
  }

  function render() {
    var d = C.cartDetails();
    var count = d.lines.reduce(function (s, l) { return s + l.qty; }, 0);

    if (!d.lines.length && !d.unavailable.length) {
      subtitle.textContent = "Your cart is empty.";
      root.innerHTML =
        '<div class="empty-state" style="margin:24px 0">' +
        '<div class="empty-icon">' + UI.ICONS.cart + "</div>" +
        "<h2>Your cart is empty</h2><p>Looks like you haven't added anything yet. Explore cases, chargers and more.</p>" +
        '<a class="btn btn-dark" href="index.html#shop">Continue shopping</a></div>';
      return;
    }

    subtitle.textContent = count + (count === 1 ? " item" : " items") + " in your cart.";

    var items = d.lines.map(function (l) {
      var p = l.product;
      var url = "product.html?id=" + encodeURIComponent(p.id);
      return (
        '<div class="cart-item" data-id="' + esc(p.id) + '" data-variant="' + esc(l.variant) + '">' +
        '<a href="' + url + '">' + C.imgTag(p.images[0], p.name) + "</a>" +
        "<div>" +
        '<h3><a href="' + url + '">' + esc(p.name) + "</a></h3>" +
        '<div class="meta">' + (l.variant ? esc((p.variantLabel || "Option") + ": " + l.variant) + " · " : "") + C.formatPrice(l.unit) + " each" +
        (l.qty >= p.stock ? " · Max stock reached" : "") + "</div>" +
        '<div class="cart-item-controls">' +
        '<div class="qty qty-sm"><button type="button" data-act="dec" aria-label="Decrease quantity">−</button>' +
        '<input type="number" min="1" max="' + p.stock + '" value="' + l.qty + '" data-act="set" aria-label="Quantity">' +
        '<button type="button" data-act="inc" aria-label="Increase quantity"' + (l.qty >= p.stock ? " disabled" : "") + ">+</button></div>" +
        '<button type="button" class="link-btn" data-act="remove">Remove</button>' +
        "</div></div>" +
        '<div class="cart-item-total">' + C.formatPrice(l.total) + (l.qty > 1 ? "<small>" + l.qty + " × " + C.formatPrice(l.unit) + "</small>" : "") + "</div>" +
        "</div>"
      );
    }).join("");

    var unavailable = d.unavailable.map(function (u) {
      return (
        '<div class="cart-item" data-id="' + esc(u.line.id) + '" data-variant="' + esc(u.line.variant) + '">' +
        (u.product ? C.imgTag(u.product.images[0], u.product.name) : '<img src="' + C.PLACEHOLDER + '" alt="">') +
        "<div><h3>" + esc(u.product ? u.product.name : "Unavailable product") + '</h3><div class="meta">' + (u.product ? "Out of stock — not included in your total." : "No longer sold — not included in your total.") + "</div>" +
        '<button type="button" class="link-btn" data-act="remove">Remove</button></div><div></div></div>'
      );
    }).join("");

    var cta = d.lines.length
      ? '<a class="btn btn-dark btn-block" href="checkout.html">Proceed to checkout</a>'
      : '<button class="btn btn-dark btn-block" disabled>Proceed to checkout</button>';
    cta += '<a class="btn btn-ghost btn-block" href="index.html#shop">Continue shopping</a>' +
      '<p class="hint" style="margin-top:14px">Your cart is saved in this browser, so it stays here if you close the tab.</p>';

    root.innerHTML =
      '<div class="cart-layout">' +
      '<div class="cart-list">' + items + unavailable +
      '<div><button type="button" class="link-btn" id="clearCart">Clear cart</button></div></div>' +
      summaryHTML(d, cta) +
      "</div>";
    C.hydrateImages(root);
  }

  root.addEventListener("click", function (e) {
    if (e.target.id === "clearCart") {
      if (confirm("Remove all items from your cart?")) { C.clearCart(); render(); }
      return;
    }
    var btn = e.target.closest("[data-act]");
    if (!btn || btn.tagName === "INPUT") return;
    var row = btn.closest(".cart-item");
    var id = row.getAttribute("data-id");
    var variant = row.getAttribute("data-variant");
    var line = C.getCart().find(function (l) { return l.id === id && (l.variant || "") === variant; });
    var act = btn.getAttribute("data-act");
    if (act === "remove") {
      C.removeFromCart(id, variant);
      UI.toast("Item removed from cart.");
    } else if (line && act === "inc") {
      C.setCartQty(id, variant, line.qty + 1);
    } else if (line && act === "dec") {
      if (line.qty <= 1) {
        C.removeFromCart(id, variant);
        UI.toast("Item removed from cart.");
      } else C.setCartQty(id, variant, line.qty - 1);
    }
    render();
  });

  root.addEventListener("change", function (e) {
    if (e.target.getAttribute("data-act") !== "set") return;
    var row = e.target.closest(".cart-item");
    var n = parseInt(e.target.value, 10);
    if (isNaN(n) || n < 1) n = 1;
    C.setCartQty(row.getAttribute("data-id"), row.getAttribute("data-variant"), n);
    render();
  });

  document.addEventListener("coverly:cart-external", render);
  render();
})();
