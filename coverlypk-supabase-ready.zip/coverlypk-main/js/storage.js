/*
 * Coverly.pk — browser-local data layer.
 *
 * Everything here lives in THIS browser only:
 *   localStorage  → products, settings, cart, demo orders, customer profile
 *   IndexedDB     → watermarked product images uploaded through the admin panel
 * Nothing is sent to a server, and nothing syncs between devices.
 */
(function () {
  "use strict";

  var KEYS = {
    products: "coverly_products_v1",
    settings: "coverly_settings_v1",
    cart: "coverly_cart_v1",
    orders: "coverly_orders_v1",
    account: "coverly_account_v1"
  };

  var SEED = window.COVERLY_SEED || { settings: {}, products: [] };

  function readJSON(key, fallback) {
    try {
      var raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) {
      return fallback;
    }
  }

  function writeJSON(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (e) {
      alert("Your browser storage is full or blocked, so this change could not be saved.");
      return false;
    }
  }

  function clone(v) {
    return JSON.parse(JSON.stringify(v));
  }

  /* ---------- Helpers ---------- */

  function escapeHTML(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function slugify(text) {
    return String(text || "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 60);
  }

  function formatPrice(amount) {
    var s = getSettings();
    var n = Math.round(Number(amount) || 0);
    return (s.currency || "Rs.") + " " + n.toLocaleString("en-PK");
  }

  function param(name) {
    return new URLSearchParams(window.location.search).get(name);
  }

  /* ---------- Settings ---------- */

  function getSettings() {
    var saved = readJSON(KEYS.settings, {});
    return Object.assign({}, clone(SEED.settings), saved);
  }

  function saveSettings(settings) {
    return writeJSON(KEYS.settings, settings);
  }

  /* ---------- Products ---------- */

  function normaliseProduct(p) {
    return {
      id: String(p.id),
      name: String(p.name || "Untitled product"),
      category: String(p.category || "Other"),
      description: String(p.description || ""),
      price: Math.max(0, Number(p.price) || 0),
      salePrice: p.salePrice === null || p.salePrice === "" || p.salePrice === undefined ? null : Math.max(0, Number(p.salePrice) || 0),
      images: Array.isArray(p.images) ? p.images.filter(Boolean).map(String) : [],
      variantLabel: String(p.variantLabel || ""),
      variants: Array.isArray(p.variants) ? p.variants.filter(Boolean).map(String) : [],
      stock: Math.max(0, parseInt(p.stock, 10) || 0),
      featured: !!p.featured,
      sold: Math.max(0, parseInt(p.sold, 10) || 0),
      createdAt: p.createdAt || new Date().toISOString().slice(0, 10)
    };
  }

  /** True when the admin has saved a custom catalogue in this browser. */
  function hasLocalCatalogue() {
    return localStorage.getItem(KEYS.products) !== null;
  }

  function getProducts() {
    var list = readJSON(KEYS.products, null);
    if (!Array.isArray(list)) list = clone(SEED.products || []);
    return list.map(normaliseProduct);
  }

  function saveProducts(list) {
    return writeJSON(KEYS.products, list.map(normaliseProduct));
  }

  function resetProducts() {
    localStorage.removeItem(KEYS.products);
  }

  function getProduct(id) {
    return getProducts().find(function (p) { return p.id === id; }) || null;
  }

  function effectivePrice(p) {
    return p.salePrice !== null && p.salePrice < p.price ? p.salePrice : p.price;
  }

  function discountPercent(p) {
    if (p.salePrice === null || p.salePrice >= p.price || !p.price) return 0;
    return Math.round((1 - p.salePrice / p.price) * 100);
  }

  function getCategories() {
    var fromSettings = getSettings().categories || [];
    var fromProducts = getProducts().map(function (p) { return p.category; });
    var all = [];
    fromSettings.concat(fromProducts).forEach(function (c) {
      if (c && all.indexOf(c) === -1) all.push(c);
    });
    return all;
  }

  /* ---------- Cart ---------- */

  function getCart() {
    var cart = readJSON(KEYS.cart, []);
    return Array.isArray(cart) ? cart : [];
  }

  function saveCart(cart) {
    writeJSON(KEYS.cart, cart);
    document.dispatchEvent(new CustomEvent("coverly:cart"));
  }

  function lineKey(id, variant) {
    return id + "::" + (variant || "");
  }

  function addToCart(id, qty, variant) {
    var product = getProduct(id);
    if (!product) return { ok: false, message: "This product is no longer available." };
    if (product.stock <= 0) return { ok: false, message: "Sorry, this product is out of stock." };
    qty = Math.max(1, parseInt(qty, 10) || 1);
    var cart = getCart();
    var key = lineKey(id, variant);
    var line = cart.find(function (l) { return lineKey(l.id, l.variant) === key; });
    var current = line ? line.qty : 0;
    var allowed = Math.min(qty, product.stock - current);
    if (allowed <= 0) return { ok: false, message: "You already have all " + product.stock + " available units in your cart." };
    if (line) line.qty += allowed;
    else cart.push({ id: id, variant: variant || "", qty: allowed });
    saveCart(cart);
    var msg = allowed < qty ? "Only " + allowed + " more could be added (stock limit)." : "Added to cart.";
    return { ok: true, message: msg };
  }

  function setCartQty(id, variant, qty) {
    var cart = getCart();
    var key = lineKey(id, variant);
    var product = getProduct(id);
    qty = parseInt(qty, 10) || 0;
    if (product) qty = Math.min(qty, product.stock);
    cart = cart
      .map(function (l) {
        if (lineKey(l.id, l.variant) === key) l.qty = qty;
        return l;
      })
      .filter(function (l) { return l.qty > 0; });
    saveCart(cart);
  }

  function removeFromCart(id, variant) {
    var key = lineKey(id, variant);
    saveCart(getCart().filter(function (l) { return lineKey(l.id, l.variant) !== key; }));
  }

  function clearCart() {
    saveCart([]);
  }

  function cartCount() {
    return getCart().reduce(function (sum, l) { return sum + l.qty; }, 0);
  }

  /** Cart lines joined with the current catalogue, plus totals. */
  function cartDetails() {
    var products = getProducts();
    var settings = getSettings();
    var lines = [];
    var unavailable = [];
    getCart().forEach(function (l) {
      var p = products.find(function (x) { return x.id === l.id; });
      if (!p || p.stock <= 0) {
        unavailable.push({ line: l, product: p || null });
        return;
      }
      var qty = Math.min(l.qty, p.stock);
      lines.push({ product: p, variant: l.variant, qty: qty, unit: effectivePrice(p), total: effectivePrice(p) * qty });
    });
    var subtotal = lines.reduce(function (s, l) { return s + l.total; }, 0);
    var threshold = Number(settings.freeShippingThreshold) || 0;
    var shipping = subtotal === 0 ? 0 : threshold > 0 && subtotal >= threshold ? 0 : Number(settings.shippingFee) || 0;
    return { lines: lines, unavailable: unavailable, subtotal: subtotal, shipping: shipping, total: subtotal + shipping, threshold: threshold };
  }

  /* ---------- Orders (demo, local only) ---------- */

  function getOrders() {
    var list = readJSON(KEYS.orders, []);
    return Array.isArray(list) ? list : [];
  }

  function saveOrders(list) {
    return writeJSON(KEYS.orders, list);
  }

  function getOrder(id) {
    return getOrders().find(function (o) { return o.id === id; }) || null;
  }

  function newOrderId() {
    var d = new Date();
    var stamp = String(d.getFullYear()).slice(2) + String(d.getMonth() + 1).padStart(2, "0") + String(d.getDate()).padStart(2, "0");
    var rand = Math.random().toString(36).slice(2, 6).toUpperCase();
    return "CV-" + stamp + "-" + rand;
  }

  function createOrder(customer, notes) {
    var details = cartDetails();
    if (!details.lines.length) return null;
    var order = {
      id: newOrderId(),
      createdAt: new Date().toISOString(),
      status: "Pending",
      customer: customer,
      notes: notes || "",
      items: details.lines.map(function (l) {
        return { id: l.product.id, name: l.product.name, variant: l.variant, qty: l.qty, unit: l.unit, total: l.total, image: l.product.images[0] || "" };
      }),
      subtotal: details.subtotal,
      shipping: details.shipping,
      total: details.total,
      paymentMethod: "Cash on Delivery",
      paymentStatus: "Unpaid — payable on delivery",
      storage: "local-browser-only"
    };
    var orders = getOrders();
    orders.unshift(order);
    if (!saveOrders(orders)) return null;
    clearCart();
    return order;
  }

  /* ---------- Customer profile (local only, no password) ---------- */

  function getAccount() {
    return readJSON(KEYS.account, null);
  }

  function saveAccount(data) {
    return writeJSON(KEYS.account, data);
  }

  function clearAccount() {
    localStorage.removeItem(KEYS.account);
  }

  /* ---------- Image store (IndexedDB) ---------- */

  var DB_NAME = "coverly-images";
  var STORE = "images";
  var dbPromise = null;
  var urlCache = {};

  function openDB() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise(function (resolve, reject) {
      if (!window.indexedDB) return reject(new Error("IndexedDB is not available in this browser."));
      var req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = function () {
        req.result.createObjectStore(STORE, { keyPath: "id" });
      };
      req.onsuccess = function () { resolve(req.result); };
      req.onerror = function () { reject(req.error || new Error("Could not open image storage.")); };
    });
    return dbPromise;
  }

  function idbRequest(mode, fn) {
    return openDB().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(STORE, mode);
        var req = fn(tx.objectStore(STORE));
        tx.oncomplete = function () { resolve(req && req.result); };
        tx.onerror = function () { reject(tx.error || new Error("Image storage error.")); };
        tx.onabort = function () { reject(tx.error || new Error("Image storage was aborted (storage may be full).")); };
      });
    });
  }

  var images = {
    isLocal: function (ref) { return typeof ref === "string" && ref.indexOf("idb:") === 0; },
    put: function (blob, meta) {
      var id = "img_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
      var record = Object.assign({ id: id, blob: blob, type: blob.type, createdAt: new Date().toISOString(), watermarked: true }, meta || {});
      return idbRequest("readwrite", function (s) { return s.put(record); }).then(function () { return "idb:" + id; });
    },
    get: function (ref) {
      var id = String(ref).replace(/^idb:/, "");
      return idbRequest("readonly", function (s) { return s.get(id); });
    },
    remove: function (ref) {
      var id = String(ref).replace(/^idb:/, "");
      if (urlCache[ref]) { URL.revokeObjectURL(urlCache[ref]); delete urlCache[ref]; }
      return idbRequest("readwrite", function (s) { return s.delete(id); });
    },
    all: function () {
      return idbRequest("readonly", function (s) { return s.getAll(); });
    },
    clear: function () {
      return idbRequest("readwrite", function (s) { return s.clear(); });
    },
    /** Resolve any image reference to a URL usable in <img src>. */
    url: function (ref) {
      if (!images.isLocal(ref)) return Promise.resolve(ref);
      if (urlCache[ref]) return Promise.resolve(urlCache[ref]);
      return images.get(ref).then(function (rec) {
        if (!rec || !rec.blob) return null;
        urlCache[ref] = URL.createObjectURL(rec.blob);
        return urlCache[ref];
      }).catch(function () { return null; });
    }
  };

  var PLACEHOLDER = "assets/products/placeholder.svg";

  /** Build an <img> tag for an image reference (path or idb:). Call hydrateImages() after inserting. */
  function imgTag(ref, alt, cls, extra) {
    var attrs = ' alt="' + escapeHTML(alt || "") + '"' + (cls ? ' class="' + cls + '"' : "") + (extra || "");
    if (!ref) return '<img src="' + PLACEHOLDER + '"' + attrs + ">";
    if (images.isLocal(ref)) return '<img src="' + PLACEHOLDER + '" data-img-ref="' + escapeHTML(ref) + '"' + attrs + ">";
    return '<img src="' + escapeHTML(ref) + '"' + attrs + ' loading="lazy" onerror="this.onerror=null;this.src=\'' + PLACEHOLDER + "'\">";
  }

  function hydrateImages(root) {
    (root || document).querySelectorAll("img[data-img-ref]").forEach(function (img) {
      var ref = img.getAttribute("data-img-ref");
      img.removeAttribute("data-img-ref");
      images.url(ref).then(function (u) { if (u) img.src = u; });
    });
  }

  function blobToDataURL(blob) {
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onload = function () { resolve(r.result); };
      r.onerror = function () { reject(r.error); };
      r.readAsDataURL(blob);
    });
  }

  function dataURLToBlob(dataUrl) {
    var parts = String(dataUrl).split(",");
    var mime = (parts[0].match(/data:([^;]+)/) || [])[1] || "image/jpeg";
    var bin = atob(parts[1] || "");
    var arr = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    return new Blob([arr], { type: mime });
  }

  window.Coverly = {
    KEYS: KEYS,
    SEED: SEED,
    escapeHTML: escapeHTML,
    slugify: slugify,
    formatPrice: formatPrice,
    param: param,
    getSettings: getSettings,
    saveSettings: saveSettings,
    getProducts: getProducts,
    saveProducts: saveProducts,
    resetProducts: resetProducts,
    hasLocalCatalogue: hasLocalCatalogue,
    getProduct: getProduct,
    normaliseProduct: normaliseProduct,
    effectivePrice: effectivePrice,
    discountPercent: discountPercent,
    getCategories: getCategories,
    getCart: getCart,
    addToCart: addToCart,
    setCartQty: setCartQty,
    removeFromCart: removeFromCart,
    clearCart: clearCart,
    cartCount: cartCount,
    cartDetails: cartDetails,
    getOrders: getOrders,
    saveOrders: saveOrders,
    getOrder: getOrder,
    createOrder: createOrder,
    getAccount: getAccount,
    saveAccount: saveAccount,
    clearAccount: clearAccount,
    images: images,
    imgTag: imgTag,
    hydrateImages: hydrateImages,
    blobToDataURL: blobToDataURL,
    dataURLToBlob: dataURLToBlob,
    PLACEHOLDER: PLACEHOLDER
  };
})();
