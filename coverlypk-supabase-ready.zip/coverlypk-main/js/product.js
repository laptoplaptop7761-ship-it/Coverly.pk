/* Coverly.pk — product details page (product.html?id=<product-id>). */
(function () {
  "use strict";
  var C = window.Coverly;
  var UI = window.CoverlyUI;
  var esc = C.escapeHTML;
  var root = document.getElementById("productRoot");

  var id = C.param("id");
  var p = id ? C.getProduct(id) : null;

  if (!p) {
    document.title = "Product not found — Coverly.pk";
    root.innerHTML =
      '<div class="empty-state" style="margin:40px 0"><div class="empty-icon">' + UI.ICONS.search + "</div>" +
      "<h2>Product not found</h2><p>This product may have been removed or the link is incorrect.</p>" +
      '<a class="btn btn-dark" href="index.html#shop">Browse all products</a></div>';
    return;
  }

  document.title = p.name + " — Coverly.pk";
  var meta = document.querySelector('meta[name="description"]');
  if (meta) meta.setAttribute("content", p.description.slice(0, 155));

  var images = p.images.length ? p.images : [""];
  var state = { index: 0, variant: p.variants[0] || "", qty: 1 };
  var off = C.discountPercent(p);
  var out = p.stock <= 0;
  var low = !out && p.stock <= 10;
  var settings = C.getSettings();

  var stockText = out ? "Out of stock" : low ? "Only " + p.stock + " left in stock" : "In stock — ready to ship";

  root.innerHTML =
    '<nav class="breadcrumbs" aria-label="Breadcrumb"><a href="index.html">Home</a><span>/</span>' +
    '<a href="index.html?category=' + encodeURIComponent(p.category) + '#shop">' + esc(p.category) + "</a><span>/</span><span>" + esc(p.name) + "</span></nav>" +
    '<div class="pdp">' +
    '<div class="gallery">' +
    '<div class="gallery-main">' + C.imgTag(images[0], p.name, "", ' id="mainImage"') +
    (images.length > 1
      ? '<button class="gallery-nav prev" data-step="-1" aria-label="Previous image"><svg viewBox="0 0 24 24"><path d="m15 6-6 6 6 6"/></svg></button>' +
        '<button class="gallery-nav next" data-step="1" aria-label="Next image"><svg viewBox="0 0 24 24"><path d="m9 6 6 6-6 6"/></svg></button>'
      : "") +
    "</div>" +
    (images.length > 1
      ? '<div class="thumbs" role="tablist" aria-label="Product images">' +
        images.map(function (ref, i) {
          return '<button class="thumb' + (i === 0 ? " active" : "") + '" data-index="' + i + '" aria-label="Show image ' + (i + 1) + '">' + C.imgTag(ref, "") + "</button>";
        }).join("") + "</div>"
      : "") +
    "</div>" +
    '<div class="pdp-info">' +
    '<span class="product-cat">' + esc(p.category) + "</span>" +
    "<h1>" + esc(p.name) + "</h1>" +
    '<div class="pdp-price">' + UI.priceHTML(p) + (off ? '<span class="save-tag">Save ' + off + "%</span>" : "") + "</div>" +
    '<div class="stock' + (out ? " out" : low ? " low" : "") + '">' + esc(stockText) + "</div>" +
    '<p class="pdp-desc">' + esc(p.description).replace(/\n/g, "<br>") + "</p>" +
    (p.variants.length
      ? '<div class="option-label">' + esc(p.variantLabel || "Option") + ': <span id="variantName">' + esc(state.variant) + "</span></div>" +
        '<div class="variants" role="group" aria-label="' + esc(p.variantLabel || "Option") + '">' +
        p.variants.map(function (v, i) {
          return '<button type="button" class="variant" data-variant="' + esc(v) + '" aria-pressed="' + (i === 0) + '">' + esc(v) + "</button>";
        }).join("") + "</div>"
      : "") +
    '<div class="option-label">Quantity</div>' +
    '<div class="buy-row">' +
    '<div class="qty"><button type="button" data-qty="-1" aria-label="Decrease quantity">−</button>' +
    '<input id="qtyInput" type="number" min="1" max="' + p.stock + '" value="1" aria-label="Quantity"' + (out ? " disabled" : "") + ">" +
    '<button type="button" data-qty="1" aria-label="Increase quantity">+</button></div>' +
    '<button class="btn btn-dark" id="addBtn"' + (out ? " disabled" : "") + ">" + (out ? "Out of stock" : "Add to cart") + "</button>" +
    "</div>" +
    '<button class="btn btn-block" id="buyBtn"' + (out ? " disabled" : "") + ">Buy now</button>" +
    '<ul class="pdp-perks">' +
    "<li>" + UI.ICONS.cash + "Cash on delivery — pay when it arrives</li>" +
    "<li>" + UI.ICONS.truck + (Number(settings.freeShippingThreshold) > 0 ? "Free delivery on orders over " + esc(C.formatPrice(settings.freeShippingThreshold)) : "Delivery " + esc(C.formatPrice(settings.shippingFee))) + "</li>" +
    "<li>" + UI.ICONS.returns + '7-day returns on eligible items · <a class="link-btn" href="policies.html#returns">Return policy</a></li>' +
    "</ul>" +
    "</div></div>";

  C.hydrateImages(root);

  var mainImg = document.getElementById("mainImage");
  var thumbs = root.querySelectorAll(".thumb");
  var qtyInput = document.getElementById("qtyInput");

  function showImage(i) {
    state.index = (i + images.length) % images.length;
    var ref = images[state.index];
    C.images.url(ref).then(function (u) { mainImg.src = u || C.PLACEHOLDER; });
    thumbs.forEach(function (t, n) { t.classList.toggle("active", n === state.index); });
  }

  root.addEventListener("click", function (e) {
    var thumb = e.target.closest(".thumb");
    if (thumb) return showImage(Number(thumb.getAttribute("data-index")));
    var step = e.target.closest("[data-step]");
    if (step) return showImage(state.index + Number(step.getAttribute("data-step")));
    var v = e.target.closest("[data-variant]");
    if (v) {
      state.variant = v.getAttribute("data-variant");
      root.querySelectorAll("[data-variant]").forEach(function (b) { b.setAttribute("aria-pressed", String(b === v)); });
      document.getElementById("variantName").textContent = state.variant;
      return;
    }
    var q = e.target.closest("[data-qty]");
    if (q && !out) setQty(state.qty + Number(q.getAttribute("data-qty")));
  });

  function setQty(n) {
    n = parseInt(n, 10);
    if (isNaN(n) || n < 1) n = 1;
    if (out) {
      qtyInput.value = 1;
      root.querySelectorAll("[data-qty]").forEach(function (b) { b.disabled = true; });
      return;
    }
    if (n > p.stock) {
      n = p.stock;
      UI.toast("Only " + p.stock + " in stock.", true);
    }
    state.qty = n;
    qtyInput.value = n;
    root.querySelector('[data-qty="-1"]').disabled = out || n <= 1;
    root.querySelector('[data-qty="1"]').disabled = out || n >= p.stock;
  }
  qtyInput.addEventListener("change", function () { setQty(qtyInput.value); });
  setQty(1);

  document.getElementById("addBtn").addEventListener("click", function () {
    var res = C.addToCart(p.id, state.qty, state.variant);
    UI.toast(res.ok ? p.name + (state.variant ? " (" + state.variant + ")" : "") + " — " + res.message : res.message, !res.ok, res.ok ? { href: "cart.html", label: "View cart" } : null);
  });

  document.getElementById("buyBtn").addEventListener("click", function () {
    var res = C.addToCart(p.id, state.qty, state.variant);
    var inCart = C.getCart().some(function (l) { return l.id === p.id && l.variant === state.variant; });
    if (res.ok || inCart) location.href = "checkout.html";
    else UI.toast(res.message, true);
  });

  // Related: same category first, then other popular items
  var all = C.getProducts().filter(function (x) { return x.id !== p.id; });
  var related = all.filter(function (x) { return x.category === p.category; })
    .concat(all.filter(function (x) { return x.category !== p.category; }).sort(function (a, b) { return b.sold - a.sold; }))
    .slice(0, 4);
  if (related.length) {
    document.getElementById("relatedSection").hidden = false;
    UI.renderGrid(document.getElementById("relatedGrid"), related);
  }
})();
