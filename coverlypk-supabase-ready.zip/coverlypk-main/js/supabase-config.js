/* Add your Supabase project URL and publishable/anon key here.
   These two values are intended for browser use. NEVER put service_role/secret keys here. */
window.COVERLY_SUPABASE_CONFIG = {
  url: "https://YOUR-PROJECT-REF.supabase.co",
  anonKey: "YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY"
};
