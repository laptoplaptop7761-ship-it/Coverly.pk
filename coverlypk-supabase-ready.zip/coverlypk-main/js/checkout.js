/* Coverly.pk — checkout: validation and local demo order creation. */
(function () {
  "use strict";
  var C = window.Coverly;
  var UI = window.CoverlyUI;
  var esc = C.escapeHTML;

  var form = document.getElementById("checkoutForm");
  var summary = document.getElementById("summary");
  var errors = document.getElementById("formErrors");

  function renderEmpty() {
    document.getElementById("checkoutRoot").innerHTML =
      '<div class="empty-state" style="margin:24px 0"><div class="empty-icon">' + UI.ICONS.cart + "</div>" +
      "<h2>Your cart is empty</h2><p>Add a few products before checking out.</p>" +
      '<a class="btn btn-dark" href="index.html#shop">Continue shopping</a></div>';
  }

  function renderSummary() {
    var d = C.cartDetails();
    if (!d.lines.length) return renderEmpty();
    summary.innerHTML =
      "<h2>Order summary</h2>" +
      d.lines.map(function (l) {
        return '<div class="mini-line">' + C.imgTag(l.product.images[0], l.product.name) +
          "<div><div>" + esc(l.product.name) + '</div><div class="meta">' + (l.variant ? esc(l.variant) + " · " : "") + "Qty " + l.qty + "</div></div>" +
          "<strong>" + C.formatPrice(l.total) + "</strong></div>";
      }).join("") +
      (d.unavailable.length ? '<p class="hint" style="margin-top:10px">' + d.unavailable.length + " unavailable item(s) were left out.</p>" : "") +
      '<div style="margin-top:12px">' +
      '<div class="summary-row"><span>Subtotal</span><span>' + C.formatPrice(d.subtotal) + "</span></div>" +
      '<div class="summary-row"><span>Shipping</span><span>' + (d.shipping === 0 ? "Free" : C.formatPrice(d.shipping)) + "</span></div>" +
      '<div class="summary-row total"><span>Total (cash on delivery)</span><span>' + C.formatPrice(d.total) + "</span></div>" +
      "</div>" +
      '<button type="submit" form="checkoutForm" class="btn btn-dark btn-block" id="placeOrder">Place order</button>' +
      '<a class="btn btn-ghost btn-block" href="cart.html">Back to cart</a>' +
      '<p class="hint" style="margin-top:14px">By placing an order you agree to our <a class="link-btn" href="policies.html#terms">terms</a>. No payment is taken online.</p>';
    C.hydrateImages(summary);
  }

  // Prefill from saved local profile
  var saved = C.getAccount();
  if (saved) {
    ["name", "phone", "email", "city", "address"].forEach(function (k) {
      if (saved[k] && form.elements[k]) form.elements[k].value = saved[k];
    });
  }

  function normalisePhone(v) {
    return String(v || "").replace(/[\s\-()]/g, "");
  }

  var rules = {
    name: function (v) { return v.trim().length >= 3; },
    phone: function (v) { return /^(\+92|0092|92|0)?3\d{9}$/.test(normalisePhone(v)); },
    email: function (v) { return !v.trim() || /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()); },
    city: function (v) { return v.trim().length >= 2; },
    address: function (v) { return v.trim().length >= 10; }
  };
  var labels = { name: "full name", phone: "phone number", email: "email", city: "city", address: "address" };

  function validateField(key) {
    var el = form.elements[key];
    var ok = rules[key](el.value);
    var wrap = form.querySelector('[data-field="' + key + '"]');
    wrap.classList.toggle("invalid", !ok);
    el.setAttribute("aria-invalid", String(!ok));
    return ok;
  }

  Object.keys(rules).forEach(function (key) {
    form.elements[key].addEventListener("blur", function () {
      if (form.elements[key].value) validateField(key);
    });
    form.elements[key].addEventListener("input", function () {
      var wrap = form.querySelector('[data-field="' + key + '"]');
      if (wrap.classList.contains("invalid")) validateField(key);
    });
  });

  form.addEventListener("submit", async function (e) {
    e.preventDefault();
    var bad = Object.keys(rules).filter(function (k) { return !validateField(k); });
    if (bad.length) {
      document.getElementById("errorSummary").textContent = "Check your " + bad.map(function (k) { return labels[k]; }).join(", ") + ".";
      errors.classList.add("show");
      errors.focus();
      form.elements[bad[0]].focus();
      return;
    }
    errors.classList.remove("show");

    var d = C.cartDetails();
    if (!d.lines.length) return renderEmpty();

    var cloud = window.CoverlyCloud;
    if (cloud && cloud.configured()) {
      try {
        var activeUser = await cloud.getUser();
        if (!activeUser) {
          UI.toast("Please sign in before placing an order.", true);
          location.href = "account.html?next=checkout.html";
          return;
        }
      } catch (authError) {
        UI.toast("Could not verify your sign-in. Please try again.", true);
        return;
      }
    }

    var customer = {
      name: form.elements.name.value.trim(),
      phone: normalisePhone(form.elements.phone.value),
      email: form.elements.email.value.trim(),
      city: form.elements.city.value.trim(),
      address: form.elements.address.value.trim()
    };

    var btn = document.getElementById("placeOrder");
    if (btn) { btn.disabled = true; btn.textContent = "Saving order…"; }

    if (document.getElementById("remember").checked) C.saveAccount(customer);

    var order = C.createOrder(customer, form.elements.notes.value.trim());
    if (!order) {
      if (btn) { btn.disabled = false; btn.textContent = "Place order"; }
      UI.toast("Your order could not be saved. Please check that browser storage is enabled.", true);
      return;
    }
    var cloud = window.CoverlyCloud;
    if (cloud && cloud.configured()) {
      cloud.saveProfile({ full_name: customer.name, phone: customer.phone, city: customer.city, address: customer.address }).then(function () {
        return cloud.saveOrder(order);
      }).then(function () {
        location.href = "order-success.html?id=" + encodeURIComponent(order.id);
      }).catch(function (err) {
        UI.toast("Order was saved on this device but cloud sync failed: " + (err.message || "unknown error"), true);
        if (btn) { btn.disabled = false; btn.textContent = "Place order"; }
      });
      return;
    }
    location.href = "order-success.html?id=" + encodeURIComponent(order.id);
  });

  form.addEventListener("change", function (e) {
    if (e.target.name !== "payment") return;
    form.querySelectorAll(".pay-option").forEach(function (o) { o.classList.toggle("selected", o.contains(e.target)); });
  });

  document.addEventListener("coverly:cart-external", renderSummary);
  renderSummary();
})();
