/* Coverly.pk — shared helpers for locally stored demo orders. */
(function () {
  "use strict";
  var C = window.Coverly;
  var esc = C.escapeHTML;

  function formatDate(iso) {
    try {
      return new Date(iso).toLocaleString("en-PK", { dateStyle: "medium", timeStyle: "short" });
    } catch (e) {
      return iso;
    }
  }

  function whatsappText(order) {
    var s = C.getSettings();
    var lines = [
      "Assalam-o-Alaikum " + s.storeName + ", I'd like to place this order:",
      "",
      "Order ID: " + order.id
    ];
    order.items.forEach(function (i) {
      lines.push("• " + i.name + (i.variant ? " (" + i.variant + ")" : "") + " × " + i.qty + " — " + C.formatPrice(i.total));
    });
    lines.push(
      "",
      "Subtotal: " + C.formatPrice(order.subtotal),
      "Shipping: " + (order.shipping === 0 ? "Free" : C.formatPrice(order.shipping)),
      "Total (cash on delivery): " + C.formatPrice(order.total),
      "",
      "Name: " + order.customer.name,
      "Phone: " + order.customer.phone,
      order.customer.email ? "Email: " + order.customer.email : null,
      "City: " + order.customer.city,
      "Address: " + order.customer.address,
      order.notes ? "Notes: " + order.notes : null
    );
    return lines.filter(function (l) { return l !== null; }).join("\n");
  }

  function whatsappURL(order) {
    var num = String(C.getSettings().whatsapp || "").replace(/\D/g, "");
    if (!num) return "";
    return "https://wa.me/" + num + "?text=" + encodeURIComponent(whatsappText(order));
  }

  function itemsTable(order) {
    return order.items.map(function (i) {
      return '<div class="mini-line">' + C.imgTag(i.image, i.name) +
        "<div><div>" + esc(i.name) + '</div><div class="meta">' + (i.variant ? esc(i.variant) + " · " : "") + "Qty " + i.qty + " × " + C.formatPrice(i.unit) + "</div></div>" +
        "<strong>" + C.formatPrice(i.total) + "</strong></div>";
    }).join("");
  }

  window.CoverlyOrders = {
    formatDate: formatDate,
    whatsappText: whatsappText,
    whatsappURL: whatsappURL,
    itemsTable: itemsTable,
    STATUSES: ["Pending", "Confirmed", "Shipped", "Delivered", "Cancelled"]
  };
})();
