/* Coverly cloud layer: Supabase Auth, catalogue sync and customer orders. */
(function () {
  "use strict";
  var cfg = window.COVERLY_SUPABASE_CONFIG || {};
  var configured = !!(cfg.url && cfg.anonKey && cfg.url.indexOf("YOUR-PROJECT") === -1 && cfg.anonKey.indexOf("YOUR_") !== 0);
  var client = null;
  if (configured && window.supabase && window.supabase.createClient) {
    try { client = window.supabase.createClient(cfg.url, cfg.anonKey, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } }); }
    catch (e) { console.error("Coverly Supabase setup error:", e); }
  }
  function ready() { return !!client; }
  function requireClient() { if (!client) throw new Error("Supabase is not configured yet. Follow SUPABASE_SETUP.md and add your project URL and publishable/anon key in js/supabase-config.js."); return client; }
  async function getUser() {
    if (!client) return null;
    var r = await client.auth.getUser();
    if (r.error) return null;
    return r.data.user || null;
  }
  async function signUp(email, password, fullName) {
    var c = requireClient();
    var r = await c.auth.signUp({ email: email, password: password, options: { data: { full_name: fullName || "" }, emailRedirectTo: location.origin + location.pathname.replace(/[^/]*$/, "account.html") } });
    if (r.error) throw r.error;
    if (r.data.user && r.data.session) await saveProfile({ full_name: fullName || "", email: email });
    return r.data;
  }
  async function signIn(email, password) {
    var c = requireClient();
    var r = await c.auth.signInWithPassword({ email: email, password: password });
    if (r.error) throw r.error;
    await saveProfile({ email: email });
    return r.data;
  }
  async function signOut() { var c = requireClient(); var r = await c.auth.signOut(); if (r.error) throw r.error; }
  async function saveProfile(profile) {
    if (!client) return;
    var user = await getUser(); if (!user) return;
    var row = { id: user.id, email: user.email, full_name: profile.full_name || (user.user_metadata && user.user_metadata.full_name) || "", phone: profile.phone || null, city: profile.city || null, address: profile.address || null, updated_at: new Date().toISOString() };
    var r = await client.from("profiles").upsert(row, { onConflict: "id" });
    if (r.error) console.warn("Coverly profile sync:", r.error.message);
  }
  async function loadProfile() {
    var c = requireClient(), user = await getUser();
    if (!user) return null;
    var r = await c.from("profiles").select("id,email,full_name,phone,city,address").eq("id", user.id).maybeSingle();
    if (r.error) throw r.error;
    return r.data || { id: user.id, email: user.email, full_name: (user.user_metadata || {}).full_name || "" };
  }
  async function loadOrders() {
    var c = requireClient(), user = await getUser();
    if (!user) throw new Error("Please sign in to view your orders.");
    var r = await c.from("orders").select("id,created_at,status,customer,notes,items,subtotal,shipping,total,payment_method,payment_status").eq("user_id", user.id).order("created_at", { ascending: false });
    if (r.error) throw r.error;
    return (r.data || []).map(function (x) { return { id:x.id, createdAt:x.created_at, status:x.status, customer:x.customer, notes:x.notes, items:x.items, subtotal:Number(x.subtotal), shipping:Number(x.shipping), total:Number(x.total), paymentMethod:x.payment_method, paymentStatus:x.payment_status }; });
  }
  async function saveOrder(order) {
    var c = requireClient(), user = await getUser();
    if (!user) throw new Error("Please sign in before placing an online order.");
    var row = { id: order.id, user_id: user.id, status: order.status || "Pending", customer: order.customer, notes: order.notes || "", items: order.items, subtotal: order.subtotal, shipping: order.shipping, total: order.total, payment_method: "Cash on Delivery", payment_status: "Unpaid — payable on delivery" };
    var r = await c.from("orders").insert(row).select("id").single();
    if (r.error) throw r.error;
    return r.data;
  }
  async function syncProducts() {
    if (!client || !window.Coverly || !window.Coverly.saveProducts) return;
    try {
      var r = await client.from("products").select("id,name,category,description,price,sale_price,images,variant_label,variants,stock,featured,sold,created_at").eq("active", true).order("created_at", { ascending: false });
      if (r.error) { console.warn("Coverly product sync:", r.error.message); return; }
      if (!r.data || !r.data.length) return; // keep starter catalogue until products are added in Supabase
      var list = r.data.map(function (p) { return { id:p.id, name:p.name, category:p.category, description:p.description || "", price:Number(p.price)||0, salePrice:p.sale_price == null ? null : Number(p.sale_price), images:Array.isArray(p.images)?p.images:[], variantLabel:p.variant_label || "", variants:Array.isArray(p.variants)?p.variants:[], stock:Number(p.stock)||0, featured:!!p.featured, sold:Number(p.sold)||0, createdAt:p.created_at ? String(p.created_at).slice(0,10) : "" }; });
      var old = window.Coverly.getProducts();
      if (JSON.stringify(old) === JSON.stringify(list)) return;
      window.Coverly.saveProducts(list);
      var key = "coverly-cloud-catalogue-reloaded:" + location.pathname;
      if (!sessionStorage.getItem(key)) { sessionStorage.setItem(key, "1"); location.reload(); }
    } catch (e) { console.warn("Coverly catalogue sync unavailable:", e.message); }
  }
  window.CoverlyCloud = { configured: ready, client: function(){ return client; }, getUser:getUser, signUp:signUp, signIn:signIn, signOut:signOut, saveProfile:saveProfile, loadProfile:loadProfile, loadOrders:loadOrders, saveOrder:saveOrder, syncProducts:syncProducts };
  if (client) {
    client.auth.onAuthStateChange(function () { document.dispatchEvent(new CustomEvent("coverly:auth-change")); });
    // Run after storage.js has loaded on normal storefront pages.
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", function(){ syncProducts(); });
    else setTimeout(syncProducts, 0);
  }
})();
