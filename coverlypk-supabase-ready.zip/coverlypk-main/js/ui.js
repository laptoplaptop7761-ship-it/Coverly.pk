/*
 * Coverly.pk — shared storefront UI: header, footer, product cards, toasts.
 * Every customer page includes <div id="site-header"></div> and <div id="site-footer"></div>.
 */
(function () {
  "use strict";
  var C = window.Coverly;
  var esc = C.escapeHTML;

  var ICONS = {
    search: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
    user: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/></svg>',
    cart: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 4h2l2.4 11.2a2 2 0 0 0 2 1.6h7.7a2 2 0 0 0 2-1.5L21 8H6.2"/><circle cx="10" cy="20.5" r="1.3"/><circle cx="17" cy="20.5" r="1.3"/></svg>',
    menu: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/></svg>',
    close: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>',
    arrow: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 17 17 7M9 7h8v8"/></svg>',
    instagram: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="0.6" fill="currentColor"/></svg>',
    facebook: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 8h3V4h-3a4 4 0 0 0-4 4v3H7v4h3v6h4v-6h3l1-4h-4V8.5c0-.3.2-.5.5-.5Z"/></svg>',
    tiktok: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 3v11.5a3.5 3.5 0 1 1-3-3.46M14 3c.5 2.6 2.4 4.4 5 4.6"/></svg>',
    youtube: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="2.5" y="5.5" width="19" height="13" rx="4"/><path d="m10 9.5 5 2.5-5 2.5z" fill="currentColor"/></svg>',
    whatsapp: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 20l1.2-3.8A8 8 0 1 1 8 19z"/><path d="M9 8.5c0 3.5 3 6.5 6.5 6.5l1-1.6-2-1-1 .8a4.5 4.5 0 0 1-2.2-2.2l.8-1-1-2z" fill="currentColor" stroke="none"/></svg>',
    truck: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 6h12v10H2zM14 10h4l3 3v3h-7"/><circle cx="6" cy="18" r="1.8"/><circle cx="17" cy="18" r="1.8"/></svg>',
    shield: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 4.5 6v6c0 4.5 3.2 7.8 7.5 9 4.3-1.2 7.5-4.5 7.5-9V6z"/><path d="m8.5 12 2.5 2.5 4.5-5"/></svg>',
    cash: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="2.5" y="6" width="19" height="12" rx="2"/><circle cx="12" cy="12" r="2.6"/></svg>',
    returns: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9h11a5 5 0 0 1 0 10H8"/><path d="m8 5-4 4 4 4"/></svg>'
  };

  var LOGO = '<span class="logo-mark" aria-hidden="true"><svg viewBox="0 0 40 40"><rect x="9" y="2.5" width="22" height="35" rx="5.5" fill="none" stroke="currentColor" stroke-width="3"/><rect x="16.5" y="6.5" width="7" height="2" rx="1" fill="currentColor"/><path d="M20 14.5 26 20.5 20 26.5 14 20.5Z" fill="#888888"/><path d="M20 17.6 22.9 20.5 20 23.4 17.1 20.5Z" fill="#FFFFFF"/></svg></span><span class="logo-text">COVERLY<em>.pk</em></span>';

  function currentPage() {
    var file = (location.pathname.split("/").pop() || "index.html").replace(/\.html$/, "");
    return file || "index";
  }

  function renderHeader() {
    var mount = document.getElementById("site-header");
    if (!mount) return;
    var s = C.getSettings();
    var q = C.param("q") || "";
    var page = currentPage();
    var cats = C.getCategories().slice(0, 6);

    function navLink(href, label, key) {
      return '<a href="' + href + '"' + (page === key ? ' aria-current="page"' : "") + ">" + esc(label) + "</a>";
    }

    mount.outerHTML =
      (s.announcement ? '<div class="announcement">' + esc(s.announcement) + "</div>" : "") +
      '<header class="site-header" id="siteHeader">' +
      '<div class="container header-row">' +
      '<button class="icon-btn menu-toggle" id="menuToggle" aria-label="Open menu" aria-expanded="false" aria-controls="mobileNav">' + ICONS.menu + "</button>" +
      '<a class="logo" href="index.html" aria-label="Coverly.pk home">' + LOGO + "</a>" +
      '<form class="header-search" action="index.html" method="get" role="search">' +
      '<label class="sr-only" for="headerSearch">Search products</label>' +
      '<input id="headerSearch" name="q" type="search" placeholder="Search cases, chargers, headphones…" value="' + esc(q) + '" autocomplete="off">' +
      '<button type="submit" aria-label="Search">' + ICONS.search + "</button>" +
      "</form>" +
      '<div class="header-actions">' +
      '<a class="icon-btn" href="account.html" aria-label="My account"' + (page === "account" ? ' aria-current="page"' : "") + ">" + ICONS.user + "</a>" +
      '<a class="icon-btn cart-btn" href="cart.html" aria-label="Shopping cart">' + ICONS.cart + '<span class="cart-count" data-cart-count>0</span></a>' +
      "</div>" +
      "</div>" +
      '<nav class="main-nav" aria-label="Main">' +
      '<div class="container nav-row">' +
      navLink("index.html", "Home", "index") +
      '<a href="index.html#shop">Shop all</a>' +
      cats.map(function (c) { return '<a href="index.html?category=' + encodeURIComponent(c) + '#shop">' + esc(c) + "</a>"; }).join("") +
      navLink("my-orders.html", "My orders", "my-orders") +
      "</div>" +
      "</nav>" +
      "</header>" +
      '<div class="mobile-nav" id="mobileNav" hidden>' +
      '<div class="mobile-nav-panel" role="dialog" aria-label="Menu">' +
      '<div class="mobile-nav-head"><a class="logo" href="index.html">' + LOGO + '</a><button class="icon-btn" id="menuClose" aria-label="Close menu">' + ICONS.close + "</button></div>" +
      '<a href="index.html">Home</a><a href="index.html#shop">Shop all</a>' +
      C.getCategories().map(function (c) { return '<a href="index.html?category=' + encodeURIComponent(c) + '#shop">' + esc(c) + "</a>"; }).join("") +
      '<hr><a href="cart.html">Cart</a><a href="my-orders.html">My orders</a><a href="account.html">My account</a><a href="policies.html">Policies</a>' +
      "</div></div>";

    var toggle = document.getElementById("menuToggle");
    var nav = document.getElementById("mobileNav");
    function openNav(open) {
      nav.hidden = !open;
      toggle.setAttribute("aria-expanded", String(open));
      document.body.classList.toggle("no-scroll", open);
    }
    toggle.addEventListener("click", function () { openNav(true); });
    document.getElementById("menuClose").addEventListener("click", function () { openNav(false); });
    nav.addEventListener("click", function (e) { if (e.target === nav || e.target.tagName === "A") openNav(false); });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape" && !nav.hidden) openNav(false); });

    var header = document.getElementById("siteHeader");
    window.addEventListener("scroll", function () { header.classList.toggle("scrolled", window.scrollY > 8); }, { passive: true });

    updateCartCount();
  }

  function renderFooter() {
    var mount = document.getElementById("site-footer");
    if (!mount) return;
    var s = C.getSettings();
    var socials = ["instagram", "facebook", "tiktok", "youtube"]
      .filter(function (k) { return s[k]; })
      .map(function (k) { return '<a href="' + esc(s[k]) + '" target="_blank" rel="noopener" aria-label="' + k + '">' + ICONS[k] + "</a>"; });
    if (s.whatsapp) socials.push('<a href="https://wa.me/' + esc(String(s.whatsapp).replace(/\D/g, "")) + '" target="_blank" rel="noopener" aria-label="WhatsApp">' + ICONS.whatsapp + "</a>");

    mount.outerHTML =
      '<section class="confidence"><div class="container confidence-inner">' +
      "<div><h2>Shop with confidence.</h2><p>Eligible products may be returned within 7 days of delivery, subject to our return policy.</p>" +
      '<p class="policy-links"><a href="policies.html#returns">Return policy</a> · <a href="policies.html#privacy">Privacy</a> · <a href="policies.html#terms">Terms</a></p></div>' +
      '<ul class="trust-list">' +
      "<li>" + ICONS.cash + "<span><strong>Cash on delivery</strong>Pay when your order arrives</span></li>" +
      "<li>" + ICONS.truck + "<span><strong>Nationwide delivery</strong>Free over " + esc(C.formatPrice(s.freeShippingThreshold)) + "</span></li>" +
      "<li>" + ICONS.returns + "<span><strong>7-day returns</strong>On eligible items</span></li>" +
      "</ul></div></section>" +
      '<footer class="site-footer"><div class="container footer-grid">' +
      '<div class="footer-brand"><a class="logo logo-light" href="index.html">' + LOGO + "</a><p>" + esc(s.tagline) + '</p><div class="socials">' + socials.join("") + "</div></div>" +
      '<div><h3>Shop</h3><a href="index.html#shop">All products</a><a href="index.html#featured">Featured</a><a href="index.html#new">New arrivals</a><a href="index.html#best">Best sellers</a></div>' +
      '<div><h3>Help</h3><a href="cart.html">Cart</a><a href="my-orders.html">My orders</a><a href="account.html">My account</a><a href="policies.html">Policies</a></div>' +
      '<div><h3>Contact</h3>' +
      (s.phone ? '<a href="tel:' + esc(String(s.phone).replace(/[^\d+]/g, "")) + '">' + esc(s.phone) + "</a>" : "") +
      (s.email ? '<a href="mailto:' + esc(s.email) + '">' + esc(s.email) + "</a>" : "") +
      (s.address ? "<span>" + esc(s.address) + "</span>" : "") +
      "</div>" +
      "</div>" +
      '<div class="container footer-bottom"><span>All Rights Reserved © ' + new Date().getFullYear() + " " + esc(s.storeName) + "</span><span>Prices in Pakistani Rupees</span></div>" +
      "</footer>" +
      (s.whatsapp ? '<a class="float-chat" href="https://wa.me/' + esc(String(s.whatsapp).replace(/\D/g, "")) + '" target="_blank" rel="noopener" aria-label="Chat with Coverly on WhatsApp">' + ICONS.whatsapp + "</a>" : "");
  }

  function updateCartCount() {
    var n = C.cartCount();
    document.querySelectorAll("[data-cart-count]").forEach(function (el) {
      el.textContent = n > 99 ? "99+" : String(n);
      el.classList.toggle("is-empty", n === 0);
    });
  }

  /* ---------- Product card ---------- */

  function priceHTML(p) {
    var off = C.discountPercent(p);
    return off
      ? '<span class="price-now">' + C.formatPrice(p.salePrice) + '</span><span class="price-was">' + C.formatPrice(p.price) + "</span>"
      : '<span class="price-now">' + C.formatPrice(p.price) + "</span>";
  }

  function productCard(p) {
    var off = C.discountPercent(p);
    var url = "product.html?id=" + encodeURIComponent(p.id);
    var out = p.stock <= 0;
    var badges = "";
    if (out) badges += '<span class="badge badge-muted">Sold out</span>';
    else if (off) badges += '<span class="badge">−' + off + "%</span>";
    if (isNew(p) && !out) badges += '<span class="badge badge-light">New</span>';
    return (
      '<article class="product-card">' +
      '<a class="product-media" href="' + url + '">' + C.imgTag(p.images[0], p.name) + '<span class="badges">' + badges + "</span></a>" +
      '<div class="product-info">' +
      '<span class="product-cat">' + esc(p.category) + "</span>" +
      '<h3 class="product-name"><a href="' + url + '">' + esc(p.name) + "</a></h3>" +
      '<div class="price">' + priceHTML(p) + "</div>" +
      '<button class="btn btn-dark btn-block add-btn" data-add="' + esc(p.id) + '"' + (out ? " disabled" : "") + ">" + (out ? "Out of stock" : "Add to cart") + "</button>" +
      "</div></article>"
    );
  }

  function isNew(p) {
    var days = (Date.now() - new Date(p.createdAt).getTime()) / 86400000;
    return days >= 0 && days <= 21;
  }

  function renderGrid(el, products, emptyText) {
    if (!el) return;
    el.innerHTML = products.length ? products.map(productCard).join("") : '<p class="empty-note">' + esc(emptyText || "No products found.") + "</p>";
    C.hydrateImages(el);
  }

  /** Delegated Add-to-cart for product cards. Products with variants use their first option. */
  document.addEventListener("click", function (e) {
    var btn = e.target.closest("[data-add]");
    if (!btn) return;
    var p = C.getProduct(btn.getAttribute("data-add"));
    if (!p) return toast("This product is no longer available.", true);
    var res = C.addToCart(p.id, 1, p.variants[0] || "");
    toast(res.ok ? p.name + (p.variants[0] ? " (" + p.variants[0] + ")" : "") + " — " + res.message : res.message, !res.ok, res.ok ? { href: "cart.html", label: "View cart" } : null);
  });

  /* ---------- Toast ---------- */

  var toastTimer;
  function toast(message, isError, action) {
    var el = document.getElementById("toast");
    if (!el) {
      el = document.createElement("div");
      el.id = "toast";
      el.className = "toast";
      el.setAttribute("role", "status");
      el.setAttribute("aria-live", "polite");
      document.body.appendChild(el);
    }
    el.innerHTML = "<span>" + esc(message) + "</span>" + (action ? '<a href="' + esc(action.href) + '">' + esc(action.label) + "</a>" : "");
    el.classList.toggle("toast-error", !!isError);
    el.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.classList.remove("show"); }, 3200);
  }

  document.addEventListener("coverly:cart", updateCartCount);
  window.addEventListener("storage", function (e) {
    if (e.key === C.KEYS.cart) {
      updateCartCount();
      document.dispatchEvent(new CustomEvent("coverly:cart-external"));
    }
  });

  window.CoverlyUI = {
    ICONS: ICONS,
    LOGO: LOGO,
    productCard: productCard,
    priceHTML: priceHTML,
    renderGrid: renderGrid,
    toast: toast,
    updateCartCount: updateCartCount,
    isNew: isNew
  };

  renderHeader();
  renderFooter();
})();
