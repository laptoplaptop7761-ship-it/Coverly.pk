-- Coverly.pk Supabase schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text not null default '',
  phone text,
  city text,
  address text,
  updated_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
drop policy if exists "Customers can read own profile" on public.profiles;
create policy "Customers can read own profile" on public.profiles for select to authenticated using (auth.uid() = id);
drop policy if exists "Customers can insert own profile" on public.profiles;
create policy "Customers can insert own profile" on public.profiles for insert to authenticated with check (auth.uid() = id);
drop policy if exists "Customers can update own profile" on public.profiles;
create policy "Customers can update own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

create table if not exists public.products (
  id text primary key,
  name text not null,
  category text not null default 'Other',
  description text not null default '',
  price numeric(12,2) not null default 0 check (price >= 0),
  sale_price numeric(12,2) check (sale_price is null or sale_price >= 0),
  images jsonb not null default '[]'::jsonb,
  variant_label text not null default '',
  variants jsonb not null default '[]'::jsonb,
  stock integer not null default 0 check (stock >= 0),
  featured boolean not null default false,
  sold integer not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
alter table public.products enable row level security;
drop policy if exists "Anyone can read active products" on public.products;
create policy "Anyone can read active products" on public.products for select to anon, authenticated using (active = true);
-- Do not add public insert/update/delete policies for products. Manage products from Supabase Dashboard or a protected server/admin tool.

create table if not exists public.orders (
  id text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'Pending' check (status in ('Pending','Confirmed','Shipped','Delivered','Cancelled')),
  customer jsonb not null,
  notes text not null default '',
  items jsonb not null default '[]'::jsonb,
  subtotal numeric(12,2) not null check (subtotal >= 0),
  shipping numeric(12,2) not null check (shipping >= 0),
  total numeric(12,2) not null check (total >= 0),
  payment_method text not null default 'Cash on Delivery',
  payment_status text not null default 'Unpaid — payable on delivery',
  created_at timestamptz not null default now()
);
create index if not exists orders_user_created_idx on public.orders(user_id, created_at desc);
alter table public.orders enable row level security;
drop policy if exists "Customers can read own orders" on public.orders;
create policy "Customers can read own orders" on public.orders for select to authenticated using (auth.uid() = user_id);
drop policy if exists "Customers can create own orders" on public.orders;
create policy "Customers can create own orders" on public.orders for insert to authenticated with check (auth.uid() = user_id);
-- Customers cannot update or delete orders from the browser. Handle order status changes through a protected admin backend.
