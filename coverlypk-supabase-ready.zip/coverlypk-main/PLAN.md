# Coverly.pk — Build Plan

1. ✅ Brand assets: logo SVGs, favicon, transparent watermark PNG, watermarked product photos, banners
2. ✅ Data layer (`js/storage.js`): products, settings, cart, orders, account in localStorage; images in IndexedDB
3. ✅ Sample catalogue (`data/products.js`) — 14 products, 8 categories
4. ✅ Shared header/footer/product cards (`js/ui.js`) and stylesheet (`css/style.css`)
5. ✅ Homepage (`index.html`, `js/home.js`) — hero, categories, featured/new/best rails, promos, search/filter/sort
6. ✅ Product page (`product.html`, `js/product.js`)
7. ✅ Cart (`cart.html`, `js/cart.js`)
8. ✅ Checkout with validation (`checkout.html`, `js/checkout.js`)
9. ✅ Order confirmation (`order-success.html`, `js/orders.js`)
10. ⬜ `my-orders.html` — local order history (use `Coverly.getOrders()` + `CoverlyOrders.itemsTable`)
11. ⬜ `account.html` — local profile (`getAccount/saveAccount/clearAccount`), honest local-only notice
12. ⬜ `policies.html` (#returns, #privacy, #terms) and `404.html` — already linked from header/footer
13. ⬜ `admin.html` + `admin/` scripts — dashboard, product CRUD, Canvas watermark on upload with preview (`assets/watermarks/coverly-watermark.png`, bottom-right, ~22% width, 3% padding), store into `Coverly.images.put`, order status management, settings, JSON import/export, orders CSV export, "Download products.js"
14. ⬜ Final QA pass on all links, mobile/desktop layouts
