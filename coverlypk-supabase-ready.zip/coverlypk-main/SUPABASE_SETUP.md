# Coverly.pk — Supabase setup (email/password)

This project is a static Netlify site. The ZIP contains the integration code, but it cannot connect to your personal database until you add your own Supabase project credentials.

## 1. Create a Supabase project
1. Open https://supabase.com/ and create a project.
2. In **Project Settings → API** (or **Connect**), copy the Project URL and the publishable key / legacy anon key. Never copy a `service_role` or secret key into this website.
3. Open `js/supabase-config.js` and replace the two placeholder values:

```js
window.COVERLY_SUPABASE_CONFIG = {
  url: "https://YOUR-PROJECT-REF.supabase.co",
  anonKey: "YOUR_PUBLIC_PUBLISHABLE_OR_ANON_KEY"
};
```

The browser key is public by design; database security must come from the RLS policies below.

## 2. Create tables and policies
1. In Supabase, open **SQL Editor → New query**.
2. Copy all contents of `supabase/schema.sql`, paste them, and click **Run**.
3. In **Authentication → Providers**, make sure Email is enabled. If email confirmation is enabled, new customers must confirm their email before signing in.
4. In **Authentication → URL Configuration**, add your live Netlify URL to Site URL / Redirect URLs, plus the account page URL, for example `https://YOUR-SITE.netlify.app/**`.

## 3. Add products to the cloud catalogue
The existing 14-product sample catalogue remains as a fallback until rows exist in `public.products`. To add a cloud product, use Supabase **Table Editor → products → Insert row**. Required fields include `id`, `name`, `category`, `price`, and `stock`; `images` must be a JSON array of relative asset paths or public image URLs, e.g. `["assets/products/clear-magsafe-case.jpg"]`. `variants` must also be a JSON array. Set `active` to true. Once active product rows exist, the site syncs them to the local display cache.

**Important:** the starter site does not include a secure admin dashboard. Do not expose product write permissions to anonymous browser users. Manage products in the Supabase dashboard until a protected admin backend is built.

## 4. Deploy to Netlify
1. Upload the entire extracted `coverlypk-main` folder (not just the HTML files) or push it to your connected repository.
2. Publish directory is the folder containing `index.html`; no build command is required.
3. Open `account.html`, create an account, confirm email if requested, then sign in.
4. Add an item to the cart and place a test cash-on-delivery order while signed in. Verify the row appears in Supabase **Table Editor → orders** and in `my-orders.html`.

## What this integration does / does not do
- Email/password sign-up and sign-in use Supabase Auth; passwords are never stored in this site's own tables.
- Customer profiles and orders are stored in Supabase with row-level security, and customers can read only their own profile/orders.
- Active products can be read from Supabase. Product writes must be performed in the dashboard or by a protected server/admin tool.
- Cash on delivery only; no online payment is processed.
- Order totals are calculated in the browser in this static-site starter. Before taking real payments or relying on inventory totals, add a trusted server/Edge Function to validate prices and stock and create orders server-side. A browser-only checkout is not a tamper-proof commerce backend.
- This project does not include shipment integrations, password reset UI, or a secure admin dashboard yet.

## Troubleshooting
- “Supabase is not configured”: check `js/supabase-config.js` and ensure it was deployed.
- Sign-up succeeds but sign-in does not: check email confirmation and SMTP settings in Supabase Auth.
- Orders/products fail: re-run `supabase/schema.sql`, check the browser console, and confirm the table names/policies match the schema.
- Do not put a service-role key into `js/supabase-config.js`, GitHub, or Netlify static files.
