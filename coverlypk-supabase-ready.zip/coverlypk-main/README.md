# Coverly.pk

Static ecommerce storefront for phone accessories in a premium black / white / light-gray theme. No build step is required.

## Pages
- `index.html` — storefront and catalogue
- `product.html`, `cart.html`, `checkout.html` — product and COD checkout flow
- `account.html` — email/password sign-in and registration
- `my-orders.html` — authenticated order history
- `order-success.html` — confirmation and WhatsApp handoff

## Technology
Plain HTML, CSS and JavaScript with Supabase JS v2 loaded from a CDN. The Supabase integration lives in `js/supabase-config.js` and `js/cloud.js`. The local catalogue/cart still has browser storage fallback; cloud auth/orders require your own Supabase project.

## Setup
Follow [`SUPABASE_SETUP.md`](SUPABASE_SETUP.md), then run [`supabase/schema.sql`](supabase/schema.sql) in Supabase SQL Editor and replace the placeholder URL/key in `js/supabase-config.js`.

## Deploy to Netlify
Deploy the folder containing `index.html` as the publish directory. No build command is required. After configuring Supabase, add the live Netlify domain to Supabase Auth URL configuration.

## Security / limitations
- Never put a Supabase service-role/secret key in frontend code. Use only the public publishable/anon key with RLS enabled.
- Customer profile and order rows are protected by owner-based RLS policies.
- Public customers can read active catalogue products, but there are no public product-write policies or secure admin dashboard.
- Checkout is cash-on-delivery only. The static browser calculates the cart total; add a trusted backend/Edge Function for server-side price/stock validation before operating a production store.
- No online payment processing is included.
